/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employeemanagementprac;

import java.util.*;

public class EmployeeManagementPrac {
//Declaring variables used within the program
    static int choice;
   public static String employeeID;
   public static String employeeName;
   public static String employeeSurname;
   public static int salaryPerMonth;
public static boolean programFlag = true;
    public static void main(String[] args) {
        // TODO code application logic here
        //Declaring scanner
        Scanner input = new Scanner(System.in);
while(programFlag){//While loop to keep application running until user exits
      
    System.out.println("Enter 1 to add a new employee\n Enter 2 to search list of current employees and display the searched employees salary per year\n Enter 3 to sort and display employeees salarys in ascending order\n Enter 4 to display the current list of  employees\n And 5 to exit the program");

        choice = input.nextInt();
        input.nextLine();
         
        switch (choice) {
            case 1:
                //Case 1 deals with adding a new employee vai accepting user input via scanner
                System.out.println("Please enter employee ID");
               employeeID = input.nextLine();
                
                System.out.println("Please enter employee Name");
               employeeName = input.nextLine();
                
                System.out.println("Please enter employee Surname");
               employeeSurname = input.nextLine();
                
                System.out.println("Pleae enter the salary of the employee per month");
              salaryPerMonth =  input.nextInt();
              //New instance of employeeMethod class
                employeeMethod e = new employeeMethod();
                //Calling capture employeee
                e.captureEmployee(employeeID,employeeName,employeeSurname,salaryPerMonth);
                break;
            case 2:
                //Case 2 deals with searching for a specific employees yearly salary via calling the calcYearlySalary method on the insatnce of the employeemethod class 
                System.out.println("Please enter the employee ID you would like to search");
                employeeID=input.nextLine();
                employeeMethod f = new employeeMethod();//New instance
                f.calcYearlySalary(employeeID);
                break;
            case 3:
                ////New instance
                employeeMethod g = new employeeMethod();
                g.sort();
                break;
            case 4:
                //Case deals with diaplaying current list of employees
                employeeMethod h = new employeeMethod();
                h.display();
                break;
            case 5:
                //Case deals with shutting the program down via making the program flag false
              System.out.println("Goodbye :)");  
              programFlag = false;
            

        }
}
    }

}
