/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeemanagementprac;

/**
 *
 * @author 27662
 */
public class employee {
  public   String employeeID;
   String employeeName;
   String employeeSurname;
 public   int salaryPerMonth;

    public employee(String employeeID, String employeeName, String employeeSurname, int salaryPerMonth) {
        this.employeeID = employeeID;
        this.employeeName = employeeName;
        this.employeeSurname = employeeSurname;
        this.salaryPerMonth = salaryPerMonth;
    }

   

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeSurname() {
        return employeeSurname;
    }

    public void setEmployeeSurname(String employeeSurname) {
        this.employeeSurname = employeeSurname;
    }

    public int getSalaryPerMonth() {
        return salaryPerMonth;
    }

    public void setSalaryPerMonth(int salaryPerMonth) {
        this.salaryPerMonth = salaryPerMonth;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }
    
   
   
   
}
