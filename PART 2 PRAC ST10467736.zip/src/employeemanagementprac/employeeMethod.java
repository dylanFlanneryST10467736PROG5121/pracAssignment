/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeemanagementprac;

import java.util.*;
public class employeeMethod {
    //Declaring array list which will store the objects created via the employee classes constructor
    public static ArrayList<employee> employeeList = new ArrayList<>();
    //Declaring variable
   public static int yearlySalary;
    //Method in order to capture the employee via adding the employee to the array list
    public static void captureEmployee(String employeeID, String employeeName, String employeeSurname, int salaryPerMonth){
    employee worker = new employee(employeeID,employeeName,employeeSurname,salaryPerMonth);
    employeeList.add(worker);
    System.out.println("Employee captured successfully");
    
    
    }
    //Method to display list of employees
    public static void display(){
    for(employee worker:employeeList){
    
   System.out.println("Employee: "+worker.getEmployeeName()+" "+worker.getEmployeeSurname()+"\n"+"Monthly salary: "+worker.getSalaryPerMonth()); 
    System.out.println();
    
    }}
    //method to calculate the yearly salary of the employee
    public static String calcYearlySalary(String employeeID){
    for(employee worker:employeeList){
    
    yearlySalary = worker.getSalaryPerMonth() * 12;
    System.out.println("Employee with ID "+worker.getEmployeeID()+" earns "+yearlySalary+" per year");
    System.out.println();
    
    }
    return "salary calculated";
    
    }//Method to sort the employees salarys in ascending in order
    public static String sort(){
    
        for (int i = 0; i < employeeList.size(); i++) {
            for (int j = 0; j < employeeList.size() - i - 1; j++) {
                if (employeeList.get(j).getSalaryPerMonth() > employeeList.get(j+1).getSalaryPerMonth()) {
                    employee temp = employeeList.get(j);
                    employeeList.set(j,employeeList.get(j+1));
                    employeeList.set(j+1, temp);

                }

            }

        }
        for(employee worker : employeeList){
        System.out.println(worker.getEmployeeName()+" "+worker.getSalaryPerMonth());
        System.out.println();
        
        }
        return "salarys sorted";
    }
    
    
    
    }                    

                

            

        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

