/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package employeemanagementprac;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;
/**
 *
 * @author 27662
 */
public class employeeMethodIT {
    
    public employeeMethodIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of captureEmployee method, of class employeeMethod.
     */
    @Test
    public void testCaptureEmployee() {
        System.out.println("captureEmployee");
        String employeeID = "101";
        String employeeName = "dylie";
        String employeeSurname = "dyl";
        int salaryPerMonth = 100;
        employeeMethod.captureEmployee(employeeID, employeeName, employeeSurname, salaryPerMonth);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of display method, of class employeeMethod.
     */
    @Test
    public void testDisplay() {
        System.out.println("display");
        employeeMethod.display();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of calcYearlySalary method, of class employeeMethod.
     */
    @Test
    public void testCalcYearlySalary() {
        System.out.println("calcYearlySalary");
        employee e = new employee("101","dyl","dylie",1000);
     employeeMethod.employeeList.add(e);
        String employeeID = "101";
        employeeMethod.calcYearlySalary(employeeID);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of sort method, of class employeeMethod.
     */
    @Test
    public void testSort() {
        System.out.println("sort");
        employeeMethod.sort();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
