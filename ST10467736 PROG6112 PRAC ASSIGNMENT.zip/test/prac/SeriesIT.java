/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prac;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 27662
 */
public class SeriesIT {
    
    public SeriesIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of captureSeries method, of class Series.
     */
  

    /**
     * Test of updateSeries method, of class Series.
     */
    @Test
    public void testUpdateSeries() {
        System.out.println("updateSeries");
        String seriesId = "101";
        String seriesName = "Goonies";
        String seriesAge = "12";
        String seriesNumberOfEpisodes = "1";
        String expResult = "Series successfully updated";
        String result = Series.updateSeries(seriesId, seriesName, seriesAge, seriesNumberOfEpisodes);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of searchSeries method, of class Series.
     */
   

    /**
     * Test of deleteSeries method, of class Series.
     */
    @Test
    public void testDeleteSeries() {
        seriesModel s = new seriesModel("101","Goonies","12","1");
       
        Series.seriesList.add(s);
        System.out.println("deleteSeries");
        String seriesId = "101";
        String confirm = "y";
        String expResult = "Series was deleted";
        String result = Series.deleteSeries(seriesId,confirm);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of seriesReport method, of class Series.
     */
     @Test
    public void testDeleteSeriesNotfound() {
        seriesModel s = new seriesModel("101","Goonies","12","1");
       
        Series.seriesList.add(s);
        System.out.println("deleteSeries");
        String seriesId = "102";
        String confirm = "y";
        String expResult = "Series not found and not deleted";
        String result = Series.deleteSeries(seriesId,confirm);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of searchSeriesTest method, of class Series.
     */
    @Test
    public void testSearchSeriesTest() {
        seriesModel s = new seriesModel("101","Goonies","12","1");
       Series.seriesList.add(s);
        
        System.out.println("searchSeriesTest");
        String seriesID = "101";
        String expResult = "----------------------------------" + "\n" + "SERIES ID: " + seriesID + "\n" + "SERIES NAME: " + s.getSeriesName() + "\n" + "SERIES AGE RESTRICTION: " + s.getSeriesAge() + "\n" + "SERIES NUMBER OF EPISODES: " + s.getSeriesNumberOfEpisodes() + "\n" + "----------------------------------";
        String result = Series.searchSeriesTest(seriesID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
     @Test
    public void testSearchSeriesTestNotFound() {
        seriesModel s = new seriesModel("101","Goonies","12","1");
       Series.seriesList.add(s);
        
        System.out.println("searchSeriesTest");
        String seriesID = "102";
        String expResult = "----------------------------------\n" + "Series with Series id: " + seriesID + " was not found\n" + "----------------------------------";
        String result = Series.searchSeriesTest(seriesID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of checkAge method, of class Series.
     */
    @Test
    public void testCheckAge() {
        System.out.println("checkAge");
        String age = "4";
        String expResult = "You have entered the correct series age";
        String result = Series.checkAge(age);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
     @Test
    public void testCheckAgeInvalid() {
        System.out.println("checkAge");
        String age = "1";
        String expResult = "You have entered a incorrect series age!!!";
        String result = Series.checkAge(age);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
