/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prac;

import java.util.Scanner;

/**
 *
 * @author 27662
 */
public class Prac {
//Declaring variables utilized throughout the program

    static boolean mainFlag = true;
    static String menuChoiceInitial;

    static String mainMenuChoice;
    public static String seriesId;
    public static String seriesName;
    public static String seriesAge;
    public static String seriesNumberOfEpisodes;
    static boolean ageFlag;
    public static String confirm;

    public static void main(String[] args) {
        // TODO code application logic here
//Declaring the scanner ,used for user input
        Scanner scanner = new Scanner(System.in);
//Declaring the scanner ,used for user input
        //Displaying the menu
        displayStartMenu();
//initial start menu choice
        menuChoiceInitial = scanner.nextLine();
        //While loop which keeps application open until user decides to exit
        while (mainFlag) {

            if (menuChoiceInitial.equals("1")) {
                //  mainFlag = false;
                //Dsiplaying the secondary menu(two different menus)
                //scanner accepting user input
                displayMenu();
                mainMenuChoice = scanner.nextLine();
//Switch statement housing varying logic based on user choice 
                switch (mainMenuChoice) {
                    case "1":
                        //instance of class Series which houses the bulk of the  applications methods
                        //this case deals with capturing a new series via scanner input
                        Series s = new Series();
                        System.out.println("CAPTURE A NEW SERIES\n******************************************\n");

                        System.out.println("Enter the series id: ");
                        seriesId = scanner.nextLine();

                        System.out.println("Enter the series name: ");
                        seriesName = scanner.nextLine();

                        System.out.println("Enter the series age restriction: ");
                        seriesAge = scanner.nextLine();
//method checking if user inputted age  is valid, if statement to deal with valid and invalid cases follows
                        String ageFlag = s.checkAge(seriesAge);
                        if (ageFlag.equals("You have entered a incorrect series age!!!")) {
                            System.out.println("Please re enter the age:>");
                            scanner.nextLine();

                        } else if (ageFlag.equals("You have entered the correct series age")) {

                            System.out.println(ageFlag);

                        }
                        ;
                        scanner.nextLine();

                        System.out.println("Enter the number of episodes for " + seriesName + ": ");
                        seriesNumberOfEpisodes = scanner.nextLine();

                        s.captureSeries(seriesId, seriesName, seriesAge, seriesNumberOfEpisodes);

                        break;
                    case "2":
                        //Search series
                        System.out.println("Enter the series id to search : ");
                        String searchID = scanner.nextLine();
                        Series.searchSeries(searchID);

                        break;
                    case "3":
                        //Update series
                        System.out.println("Enter the series id to update: ");
                        String idToUpdate = scanner.nextLine();

                        System.out.println("Enter the series name:");
                        String updatedSeriesName = scanner.nextLine();

                        System.out.println("Enter the age restriction:");
                        String newAge = scanner.nextLine();

                        System.out.println("Enter the number of episodes:");
                        String newNumEpisodes = scanner.nextLine();
                        Series.updateSeries(idToUpdate, updatedSeriesName, newAge, newNumEpisodes);

                        break;
                    case "4":
                        //Delete series
                        System.out.println("Enter the series ID to delete:");
                        String deleteID = scanner.nextLine();

                        System.out.println("----------------------------------");
                        System.out.println("Are you sure you want to delete series " + seriesId + " from the system? Yes (y) to delete.");

                        confirm = scanner.nextLine().trim().toLowerCase();

                        Series.deleteSeries(deleteID, confirm);
                        break;
                    case "5":
                        //Series report
                        Series.seriesReport();
                        break;
                    case "6":
                        //Exit application
                        System.out.println("System shutting down, goodbye!");
                        mainFlag = false;
                        break;

                }

            } else if (!menuChoiceInitial.equals("1")) {
                System.out.println("Application shutting down");
                mainFlag = false;
            }

        }

    }

    //Methods
    //Method to display the first menu
    public static void displayStartMenu() {
        System.out.println("LATEST SERIES - 2025\n" + "******************************************\n" + "Enter (1) to launch menu or any other key to exit");
    }
//Method to  display the second menu
    public static void displayMenu() {
        System.out.println("(1) Capture a new series\n" + "(2) Search for a new series\n" + "(3) Update series age\n" + "(4) Delete a series\n" + "(5) Print series report - 2025\n" + "(6) Exit Application");
    }

}
