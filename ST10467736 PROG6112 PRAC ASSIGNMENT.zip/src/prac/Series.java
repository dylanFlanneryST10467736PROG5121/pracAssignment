/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prac;

import java.util.*;

/**
 *
 * @author 27662
 */
public class Series {

    public static ArrayList<seriesModel> seriesList = new ArrayList<>();

    public static void captureSeries(String seriesId, String seriesName, String seriesAge, String seriesNumberOfEpisodes) {
        seriesModel series = new seriesModel(seriesId, seriesName, seriesAge, seriesNumberOfEpisodes);
        seriesList.add(series);
        System.out.println("Series processed successfully!!!");
    }

    public static String updateSeries(String seriesId, String seriesName, String seriesAge, String seriesNumberOfEpisodes) {

        for (seriesModel series : seriesList) {
            if (series.getSeriesId().equals(seriesId)) {
                series.setSeriesName(seriesName);
                series.setSeriesAge(seriesAge);
                series.setSeriesNumberOfEpisodes(seriesAge);

            }

        }
        return "Series successfully updated";
    }

    public static void searchSeries(String seriesId) {
        boolean found = false;
        for (seriesModel series : seriesList) {
            if (series.getSeriesId().equals(seriesId)) {
                System.out.println("----------------------------------");
                System.out.println("SERIES ID: " + seriesId);
                System.out.println("SERIES NAME: " + series.getSeriesName());
                System.out.println("SERIES AGE RESTRICTION: " + series.getSeriesAge());
                System.out.println("SERIES NUMBER OF EPISODES: " + series.getSeriesNumberOfEpisodes());
                System.out.println("----------------------------------");
                found = true;
                break;

            }
        }
        if (!found) {
            System.out.println("----------------------------------");
            System.out.println("Series with Series id: " + seriesId + " was not found");
            System.out.println("----------------------------------");

        }

    }

    public static String deleteSeries(String seriesId,String confirm) {
        //Scanner scanner = new Scanner(System.in);
       

        boolean removed = seriesList.removeIf(s -> s.getSeriesId().equals(seriesId));

        if (removed && confirm.equals("y")) {
            System.out.println("Series with Series Id: " + seriesId + "was deleted!");
            System.out.println("----------------------------------");
            return "Series was deleted";
        } else {
            return "Series not found and not deleted";
        }

    }

    public static void seriesReport() {
        for (int i = 0; i < seriesList.size(); i++) {
            System.out.println("Series " + i + 1);
            System.out.println("----------------------------------");
            System.out.println("SERIES ID: " + seriesList.get(i).getSeriesId());
            System.out.println("SERIES NAME: " + seriesList.get(i).getSeriesName());
            System.out.println("SERIES AGE RESTRICTION: " + seriesList.get(i).getSeriesAge());
            System.out.println("NUMBER OF EPISODES " + seriesList.get(i).getSeriesNumberOfEpisodes());
            System.out.println("----------------------------------");

        }

    }
//Methods for testing purposes , complete the same function but return values thus working with JUNITtests better

    public static String searchSeriesTest(String seriesID) {

        boolean found = false;
        for (seriesModel series : seriesList) {
            if (series.getSeriesId().equals(seriesID)) {

                found = true;
                return "----------------------------------" + "\n" + "SERIES ID: " + seriesID + "\n" + "SERIES NAME: " + series.getSeriesName() + "\n" + "SERIES AGE RESTRICTION: " + series.getSeriesAge() + "\n" + "SERIES NUMBER OF EPISODES: " + series.getSeriesNumberOfEpisodes() + "\n" + "----------------------------------";

            }
        }
        if (!found) {
            return "----------------------------------\n" + "Series with Series id: " + seriesID + " was not found\n" + "----------------------------------";

        }
        return "";
    }

    public static String checkAge(String age) {
        int ageINT = Integer.parseInt(age);
        if (ageINT < 2 || ageINT > 18) {
            return "You have entered a incorrect series age!!!";

        } else if (ageINT >= 2 && ageINT <= 18) {

            return "You have entered the correct series age";

        }
return "";
    }
}
